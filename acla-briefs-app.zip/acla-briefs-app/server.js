'use strict';

const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const session = require('express-session');
const { SKUS, normalizeSku, grantAccess, hasAccess } = require('./lib/payments');

const PORT = process.env.PORT || 3000;
const SESSION_SECRET = process.env.SESSION_SECRET || 'acla-dev-session-secret-change-me';
const BRIEFS_DIR = path.join(__dirname, 'briefs');

const app = express();

app.disable('x-powered-by');
app.use(cookieParser());
app.use(
  session({
    name: 'acla.sid',
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000,
    },
  })
);
app.use(express.urlencoded({ extended: false }));

// CSS only. Never expose briefs/ via express.static.
app.use('/public', express.static(path.join(__dirname, 'public')));

function layout({ title, body, chrome }) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${title}</title>
  <link rel="stylesheet" href="/public/styles.css">
</head>
<body class="${chrome ? 'reader-body' : ''}">
${body}
</body>
</html>`;
}

function catalogPage() {
  return layout({
    title: 'ACLA Account Brief — Catalog',
    body: `
<header class="site-header">
  <div class="brand">ACLA Account Brief</div>
  <div class="brand-sub">Healthcare / HIPAA · September 2026</div>
</header>
<main class="wrap">
  <div class="hero">
    <div class="kicker">Prepared for Nashville MSPs</div>
    <h1>ACLA Account Brief</h1>
    <p>Two editions of the September 2026 healthcare / HIPAA brief. Each version has its own reader — choose Preview or Full.</p>
  </div>
  <div class="cards">
    <article class="card">
      <span class="badge">Edition</span>
      <h2>Preview</h2>
      <div class="price">$29</div>
      <p>Condensed account brief: ACLA positioning, HIPAA surface area, and what Nashville MSPs need to know before a first conversation.</p>
      <a class="btn" href="/preview">Open Preview</a>
    </article>
    <article class="card">
      <span class="badge">Edition</span>
      <h2>Full</h2>
      <div class="price">$149</div>
      <p>Complete brief with full HIPAA coverage, recommended MSP motions, and the unredacted account narrative. Buying Full also unlocks Preview.</p>
      <a class="btn" href="/full">Open Full</a>
    </article>
  </div>
</main>
<footer class="site-footer">
  <span>ACLA · Healthcare / HIPAA · September 2026 · Nashville MSPs</span>
  <a href="/logout">Clear session</a>
</footer>`,
  });
}

function paywallPage(sku) {
  const item = SKUS[sku];
  return layout({
    title: `Checkout — ${item.title} · ACLA Account Brief`,
    body: `
<header class="site-header">
  <div class="brand">ACLA Account Brief</div>
  <div class="brand-sub">Healthcare / HIPAA · September 2026</div>
</header>
<main class="paywall">
  <div class="kicker">Stub paywall · ${item.title} edition</div>
  <h1>Unlock the ${item.title} brief</h1>
  <div class="price">${item.price}</div>
  <p>${item.description} Prepared for Nashville MSPs, September 2026.</p>
  <p class="stub-note">Checkout stub — payment processing comes later. This form grants access without charging a card. Real Stripe charges will replace the stub grant in <code>lib/payments.js</code>.</p>
  <form method="post" action="/buy/${item.id}">
    <button class="btn" type="submit">Checkout stub — payment processing comes later</button>
  </form>
  <p style="margin-top:1.4rem;font-size:0.9rem;color:var(--muted)">
    <a href="/">Back to catalog</a>
    ${sku === 'full' ? '' : ' · <a href="/full">See Full edition ($149)</a>'}
  </p>
</main>
<footer class="site-footer">
  <span>No charge in this stub. Session access only.</span>
  <a href="/logout">Clear session</a>
</footer>`,
  });
}

function readerPage(sku) {
  const item = SKUS[sku];
  return layout({
    title: `${item.title} · ACLA Account Brief`,
    chrome: true,
    body: `
<div class="reader">
  <header class="reader-chrome">
    <div class="reader-title">
      <span class="version-label">${item.title} edition</span>
      <strong>ACLA Account Brief</strong>
    </div>
    <nav>
      <a href="/">Catalog</a>
      &nbsp;·&nbsp;
      <a href="/logout">Clear session</a>
    </nav>
  </header>
  <iframe title="ACLA Account Brief ${item.title} PDF" src="/files/${item.filename}"></iframe>
</div>`,
  });
}

function versionHandler(sku) {
  return (req, res) => {
    if (!hasAccess(req, sku)) {
      res.status(200).type('html').send(paywallPage(sku));
      return;
    }
    res.status(200).type('html').send(readerPage(sku));
  };
}

app.get('/', (req, res) => {
  res.status(200).type('html').send(catalogPage());
});

app.get('/preview', versionHandler('preview'));
app.get('/full', versionHandler('full'));

app.post('/buy/:sku', (req, res) => {
  const sku = normalizeSku(req.params.sku);
  if (!sku) {
    res.status(404).type('text').send('Unknown SKU');
    return;
  }

  // STUB CHECKOUT: no Stripe, no charge.
  // Replace this grant with a successful Stripe PaymentIntent / Checkout
  // Session confirmation before calling grantAccess(req, sku).
  grantAccess(req, sku);
  res.redirect(303, `/${sku}`);
});

app.get('/files/:file', (req, res) => {
  const file = req.params.file;
  const sku = file === 'preview.pdf' ? 'preview' : file === 'full.pdf' ? 'full' : null;
  if (!sku) {
    res.status(404).type('text').send('Not found');
    return;
  }

  if (!hasAccess(req, sku)) {
    res.set('X-Content-Type-Options', 'nosniff');
    res.status(402).type('text').send('Payment Required');
    return;
  }

  const filename = SKUS[sku].filename;
  res.set({
    'Content-Type': 'application/pdf',
    'Content-Disposition': `inline; filename="${filename}"`,
    'X-Content-Type-Options': 'nosniff',
  });
  res.sendFile(path.join(BRIEFS_DIR, filename));
});

function clearSession(req, res) {
  req.session.destroy(() => {
    res.clearCookie('acla.sid');
    res.redirect(303, '/');
  });
}

app.get('/logout', clearSession);
app.get('/clear', clearSession);

app.listen(PORT, () => {
  console.log(`ACLA briefs app listening on http://localhost:${PORT}`);
});
